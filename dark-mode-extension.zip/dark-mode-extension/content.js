chrome.storage.local.get(["darkMode"], (data) => {
  if (data.darkMode) enableDark();
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.darkMode) {
    if (changes.darkMode.newValue) enableDark();
    else disableDark();
  }
});

function enableDark() {
  const style = document.createElement("style");
  style.id = "dark-mode-style";
  style.innerHTML = `
    html {
      filter: invert(1) hue-rotate(180deg) !important;
      background: #111 !important;
    }
    img, video, iframe {
      filter: invert(1) hue-rotate(180deg) !important;
    }
  `;
  document.head.appendChild(style);
}

function disableDark() {
  const style = document.getElementById("dark-mode-style");
  if (style) style.remove();
}