const btn = document.getElementById("toggle");

btn.addEventListener("click", async () => {

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      if (document.documentElement.style.filter) {
        document.documentElement.style.filter = "";
      } else {
        document.documentElement.style.filter = "invert(1) hue-rotate(180deg)";
      }
    }
  });

});